"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { CheckCircle, XCircle, ArrowRight, ArrowLeft, Save } from "lucide-react"

type Question = {
  id: string
  question: string
  options: string[]
  correctAnswer: string
  explanation?: string
  type: "multiple-choice" | "short-answer"
}

interface QuizDisplayProps {
  questions: Question[]
}

export function QuizDisplay({ questions }: QuizDisplayProps) {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [selectedAnswers, setSelectedAnswers] = useState<Record<string, string>>({})
  const [showResults, setShowResults] = useState(false)

  const currentQuestion = questions[currentQuestionIndex]

  const handleAnswerSelect = (value: string) => {
    setSelectedAnswers({
      ...selectedAnswers,
      [currentQuestion.id]: value,
    })
  }

  const handleNext = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1)
    } else {
      setShowResults(true)
    }
  }

  const handlePrevious = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1)
    }
  }

  const calculateScore = () => {
    let correctCount = 0
    questions.forEach((question) => {
      if (selectedAnswers[question.id] === question.correctAnswer) {
        correctCount++
      }
    })
    return {
      score: correctCount,
      total: questions.length,
      percentage: Math.round((correctCount / questions.length) * 100),
    }
  }

  const handleRetakeQuiz = () => {
    setSelectedAnswers({})
    setCurrentQuestionIndex(0)
    setShowResults(false)
  }

  if (showResults) {
    const { score, total, percentage } = calculateScore()

    return (
      <Card>
        <CardHeader>
          <CardTitle>Quiz Results</CardTitle>
          <CardDescription>
            You scored {score} out of {total} ({percentage}%)
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {questions.map((question, index) => {
              const isCorrect = selectedAnswers[question.id] === question.correctAnswer

              return (
                <div key={question.id} className="rounded-lg border p-4">
                  <div className="flex items-start justify-between">
                    <div className="font-medium">
                      Question {index + 1}: {question.question}
                    </div>
                    {isCorrect ? (
                      <CheckCircle className="h-5 w-5 text-green-500" />
                    ) : (
                      <XCircle className="h-5 w-5 text-red-500" />
                    )}
                  </div>

                  <div className="mt-2">
                    <p className="text-sm text-gray-500">Your answer: {selectedAnswers[question.id]}</p>
                    {!isCorrect && (
                      <p className="text-sm font-medium text-green-600">Correct answer: {question.correctAnswer}</p>
                    )}
                  </div>

                  {question.explanation && (
                    <div className="mt-2 text-sm text-gray-600">
                      <p className="font-medium">Explanation:</p>
                      <p>{question.explanation}</p>
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </CardContent>
        <CardFooter>
          <Button onClick={handleRetakeQuiz}>Retake Quiz</Button>
          <Button variant="outline" className="ml-2">
            <Save className="mr-2 h-4 w-4" />
            Save Results
          </Button>
        </CardFooter>
      </Card>
    )
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>
          Question {currentQuestionIndex + 1} of {questions.length}
        </CardTitle>
        <CardDescription>
          {currentQuestion.type === "multiple-choice" ? "Select the best answer" : "Provide a short answer"}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="text-lg font-medium">{currentQuestion.question}</div>

          {currentQuestion.type === "multiple-choice" && (
            <RadioGroup value={selectedAnswers[currentQuestion.id] || ""} onValueChange={handleAnswerSelect}>
              {currentQuestion.options.map((option, index) => (
                <div
                  key={index}
                  className="flex items-center space-x-2 rounded-md border p-3 hover:bg-gray-100 dark:hover:bg-gray-800"
                >
                  <RadioGroupItem value={option} id={`option-${index}`} />
                  <Label htmlFor={`option-${index}`} className="flex-1 cursor-pointer">
                    {option}
                  </Label>
                </div>
              ))}
            </RadioGroup>
          )}
        </div>
      </CardContent>
      <CardFooter className="flex justify-between">
        <Button variant="outline" onClick={handlePrevious} disabled={currentQuestionIndex === 0}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Previous
        </Button>
        <Button onClick={handleNext} disabled={!selectedAnswers[currentQuestion.id]}>
          {currentQuestionIndex === questions.length - 1 ? "Finish" : "Next"}
          {currentQuestionIndex === questions.length - 1 ? null : <ArrowRight className="ml-2 h-4 w-4" />}
        </Button>
      </CardFooter>
    </Card>
  )
}

