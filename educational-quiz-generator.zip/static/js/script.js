document.addEventListener("DOMContentLoaded", () => {
  // DOM Elements
  const fileUpload = document.getElementById("file-upload")
  const uploadArea = document.getElementById("upload-area")
  const uploadContent = document.getElementById("upload-content")
  const previewContainer = document.getElementById("preview-container")
  const previewImage = document.getElementById("preview-image")
  const changeFileBtn = document.getElementById("change-file")
  const generateQuizBtn = document.getElementById("generate-quiz")
  const loadingContainer = document.getElementById("loading-container")
  const quizSection = document.getElementById("quiz-section")
  const uploadSection = document.getElementById("upload-section")
  const resultsSection = document.getElementById("results-section")
  const questionText = document.getElementById("question-text")
  const optionsContainer = document.getElementById("options-container")
  const currentQuestionEl = document.getElementById("current-question")
  const totalQuestionsEl = document.getElementById("total-questions")
  const prevBtn = document.getElementById("prev-btn")
  const nextBtn = document.getElementById("next-btn")
  const scorePercentageEl = document.getElementById("score-percentage")
  const correctAnswersEl = document.getElementById("correct-answers")
  const totalQuestionsResultsEl = document.getElementById("total-questions-results")
  const resultsDetailsEl = document.getElementById("results-details")
  const retakeBtn = document.getElementById("retake-btn")
  const newQuizBtn = document.getElementById("new-quiz-btn")

  // Quiz state
  let quizQuestions = []
  let currentQuestionIndex = 0
  let userAnswers = {}
  let selectedFile = null

  // Event Listeners
  fileUpload.addEventListener("change", handleFileSelect)
  uploadArea.addEventListener("dragover", handleDragOver)
  uploadArea.addEventListener("drop", handleDrop)
  changeFileBtn.addEventListener("click", resetFileUpload)
  generateQuizBtn.addEventListener("click", generateQuiz)
  prevBtn.addEventListener("click", showPreviousQuestion)
  nextBtn.addEventListener("click", handleNextQuestion)
  retakeBtn.addEventListener("click", retakeQuiz)
  newQuizBtn.addEventListener("click", resetQuiz)

  // Handle file selection
  function handleFileSelect(e) {
    const file = e.target.files[0]
    if (file && isValidImageFile(file)) {
      displayPreview(file)
    }
  }

  // Handle drag over
  function handleDragOver(e) {
    e.preventDefault()
    e.stopPropagation()
    uploadArea.classList.add("drag-over")
  }

  // Handle drop
  function handleDrop(e) {
    e.preventDefault()
    e.stopPropagation()
    uploadArea.classList.remove("drag-over")

    const file = e.dataTransfer.files[0]
    if (file && isValidImageFile(file)) {
      fileUpload.files = e.dataTransfer.files
      displayPreview(file)
    }
  }

  // Check if file is a valid image
  function isValidImageFile(file) {
    const validTypes = ["image/jpeg", "image/png", "image/gif"]
    return validTypes.includes(file.type)
  }

  // Display image preview
  function displayPreview(file) {
    selectedFile = file
    const reader = new FileReader()

    reader.onload = (e) => {
      previewImage.src = e.target.result
      uploadContent.style.display = "none"
      previewContainer.style.display = "block"
    }

    reader.readAsDataURL(file)
  }

  // Reset file upload
  function resetFileUpload() {
    fileUpload.value = ""
    selectedFile = null
    previewContainer.style.display = "none"
    uploadContent.style.display = "block"
  }

  // Generate quiz
  function generateQuiz() {
    if (!selectedFile) return

    // Show loading state
    uploadArea.style.display = "none"
    loadingContainer.style.display = "block"

    // Create form data
    const formData = new FormData()
    formData.append("file", selectedFile)

    // Send request to backend
    fetch("/generate-quiz", {
      method: "POST",
      body: formData,
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error("Network response was not ok")
        }
        return response.json()
      })
      .then((data) => {
        // Store quiz questions
        quizQuestions = data.questions

        // Update UI
        totalQuestionsEl.textContent = quizQuestions.length
        totalQuestionsResultsEl.textContent = quizQuestions.length

        // Show first question
        showQuestion(0)

        // Hide loading and show quiz
        loadingContainer.style.display = "none"
        uploadSection.style.display = "none"
        quizSection.style.display = "block"
      })
      .catch((error) => {
        console.error("Error generating quiz:", error)
        alert("Error generating quiz. Please try again.")
        loadingContainer.style.display = "none"
        uploadArea.style.display = "block"
      })
  }

  // Show question
  function showQuestion(index) {
    const question = quizQuestions[index]
    currentQuestionIndex = index

    // Update question number
    currentQuestionEl.textContent = index + 1

    // Set question text
    questionText.textContent = question.question

    // Clear options
    optionsContainer.innerHTML = ""

    // Add options
    question.options.forEach((option, i) => {
      const optionEl = document.createElement("div")
      optionEl.className = "option"
      if (userAnswers[index] === option) {
        optionEl.classList.add("selected")
      }

      optionEl.innerHTML = `
                <input type="radio" name="question-${index}" id="option-${index}-${i}" class="option-radio" ${userAnswers[index] === option ? "checked" : ""}>
                <label for="option-${index}-${i}">${option}</label>
            `

      optionEl.addEventListener("click", () => {
        // Select this option
        document.querySelectorAll(".option").forEach((el) => el.classList.remove("selected"))
        optionEl.classList.add("selected")
        userAnswers[index] = option

        // Enable next button
        nextBtn.disabled = false
      })

      optionsContainer.appendChild(optionEl)
    })

    // Update button states
    prevBtn.disabled = index === 0
    nextBtn.disabled = !userAnswers[index]

    // Update next button text
    if (index === quizQuestions.length - 1) {
      nextBtn.textContent = "Finish Quiz"
    } else {
      nextBtn.textContent = "Next"
    }
  }

  // Show previous question
  function showPreviousQuestion() {
    if (currentQuestionIndex > 0) {
      showQuestion(currentQuestionIndex - 1)
    }
  }

  // Handle next question or finish quiz
  function handleNextQuestion() {
    if (currentQuestionIndex < quizQuestions.length - 1) {
      showQuestion(currentQuestionIndex + 1)
    } else {
      showResults()
    }
  }

  // Show quiz results
  function showResults() {
    // Calculate score
    let correctCount = 0

    quizQuestions.forEach((question, index) => {
      if (userAnswers[index] === question.correctAnswer) {
        correctCount++
      }
    })

    const percentage = Math.round((correctCount / quizQuestions.length) * 100)

    // Update results summary
    scorePercentageEl.textContent = `${percentage}%`
    correctAnswersEl.textContent = correctCount

    // Generate results details
    resultsDetailsEl.innerHTML = ""

    quizQuestions.forEach((question, index) => {
      const isCorrect = userAnswers[index] === question.correctAnswer

      const resultItem = document.createElement("div")
      resultItem.className = "result-item"

      resultItem.innerHTML = `
                <div class="result-question">Question ${index + 1}: ${question.question}</div>
                <div class="result-answer ${isCorrect ? "correct" : "incorrect"}">
                    <span class="result-icon">${isCorrect ? "✓" : "✗"}</span>
                    <span>Your answer: ${userAnswers[index]}</span>
                </div>
                ${
                  !isCorrect
                    ? `<div class="result-answer correct">
                    <span class="result-icon">✓</span>
                    <span>Correct answer: ${question.correctAnswer}</span>
                </div>`
                    : ""
                }
                ${
                  question.explanation
                    ? `<div class="result-explanation">
                    <strong>Explanation:</strong> ${question.explanation}
                </div>`
                    : ""
                }
            `

      resultsDetailsEl.appendChild(resultItem)
    })

    // Show results section
    quizSection.style.display = "none"
    resultsSection.style.display = "block"
  }

  // Retake the same quiz
  function retakeQuiz() {
    // Reset user answers
    userAnswers = {}

    // Show first question
    showQuestion(0)

    // Show quiz section
    resultsSection.style.display = "none"
    quizSection.style.display = "block"
  }

  // Reset everything for a new quiz
  function resetQuiz() {
    // Reset state
    quizQuestions = []
    currentQuestionIndex = 0
    userAnswers = {}

    // Reset UI
    resetFileUpload()

    // Show upload section
    resultsSection.style.display = "none"
    uploadSection.style.display = "block"
    uploadArea.style.display = "block"
  }

  // For demo purposes, add mock data function
  window.loadMockQuiz = () => {
    quizQuestions = [
      {
        question: "What is the primary function of photosynthesis?",
        options: [
          "Converting light energy to chemical energy",
          "Breaking down food for energy",
          "Cellular respiration",
          "Nitrogen fixation",
        ],
        correctAnswer: "Converting light energy to chemical energy",
        explanation:
          "Photosynthesis is the process by which green plants and some other organisms use sunlight to synthesize foods with carbon dioxide and water, generating oxygen as a byproduct.",
      },
      {
        question: "Which organelle is the site of photosynthesis in plant cells?",
        options: ["Mitochondria", "Chloroplast", "Nucleus", "Golgi apparatus"],
        correctAnswer: "Chloroplast",
        explanation:
          "Chloroplasts contain chlorophyll, which captures light energy and is essential for photosynthesis.",
      },
      {
        question: "What are the two main stages of photosynthesis?",
        options: [
          "Glycolysis and Krebs cycle",
          "Light-dependent reactions and Calvin cycle",
          "Transcription and translation",
          "Mitosis and meiosis",
        ],
        correctAnswer: "Light-dependent reactions and Calvin cycle",
        explanation:
          "The light-dependent reactions capture energy from sunlight, while the Calvin cycle uses that energy to produce glucose from carbon dioxide.",
      },
      {
        question: "Which of the following is NOT a part of a plant cell?",
        options: ["Cell wall", "Chloroplast", "Flagellum", "Vacuole"],
        correctAnswer: "Flagellum",
        explanation: "Flagella are typically found in animal cells and some bacteria, not in plant cells.",
      },
      {
        question: "What gas is release  not in plant cells.",
      },
      {
        question: "What gas is released as a byproduct of photosynthesis?",
        options: ["Carbon dioxide", "Oxygen", "Nitrogen", "Hydrogen"],
        correctAnswer: "Oxygen",
        explanation: "During photosynthesis, plants use carbon dioxide and water to produce glucose and oxygen.",
      },
    ]

    // Update UI
    totalQuestionsEl.textContent = quizQuestions.length
    totalQuestionsResultsEl.textContent = quizQuestions.length

    // Show first question
    showQuestion(0)

    // Hide upload and show quiz
    uploadSection.style.display = "none"
    quizSection.style.display = "block"
  }
})

