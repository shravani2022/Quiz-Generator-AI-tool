from flask import Flask, render_template, request, jsonify
import os
import numpy as np
import tensorflow as tf
from tensorflow.keras.applications import VGG16, ResNet50
from tensorflow.keras.preprocessing import image
from tensorflow.keras.applications.vgg16 import preprocess_input
from tensorflow.keras.models import Model
from PIL import Image
import io
import random

app = Flask(__name__)

# Configure upload folder
UPLOAD_FOLDER = 'uploads'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Load pre-trained CNN model
def load_model():
    # Load VGG16 model pre-trained on ImageNet
    base_model = VGG16(weights='imagenet', include_top=True)
    
    # Create a new model that outputs features from the second-to-last layer
    feature_model = Model(inputs=base_model.input, 
                         outputs=base_model.get_layer('fc2').output)
    
    return feature_model

# Extract features from image using CNN
def extract_features(img_path, model):
    # Load and preprocess image
    img = image.load_img(img_path, target_size=(224, 224))
    x = image.img_to_array(img)
    x = np.expand_dims(x, axis=0)
    x = preprocess_input(x)
    
    # Extract features
    features = model.predict(x)
    
    return features

# Map features to educational topics
def map_features_to_topics(features):
    # In a real application, this would use a trained classifier
    # For demo purposes, we'll use a simplified approach
    
    # Normalize features
    features = features / np.linalg.norm(features)
    
    # Predefined topics with feature vectors (simplified)
    topics = {
        'Photosynthesis': np.random.rand(4096),
        'Cell Biology': np.random.rand(4096),
        'Genetics': np.random.rand(4096),
        'Human Anatomy': np.random.rand(4096),
        'Physics': np.random.rand(4096),
        'Chemistry': np.random.rand(4096),
        'Mathematics': np.random.rand(4096),
        'History': np.random.rand(4096),
    }
    
    # Normalize topic vectors
    for topic in topics:
        topics[topic] = topics[topic] / np.linalg.norm(topics[topic])
    
    # Calculate similarity scores
    similarities = {}
    for topic, topic_features in topics.items():
        similarity = np.dot(features.flatten(), topic_features)
        similarities[topic] = float(similarity)
    
    # Sort by similarity
    sorted_topics = sorted(similarities.items(), key=lambda x: x[1], reverse=True)
    
    # Return top 3 topics
    return [topic for topic, score in sorted_topics[:3]]

# Generate questions based on topics
def generate_questions(topics):
    # In a real application, this would use NLP techniques
    # For demo purposes, we'll use predefined questions
    
    question_bank = {
        'Photosynthesis': [
            {
                'question': 'What is the primary function of photosynthesis?',
                'options': [
                    'Converting light energy to chemical energy',
                    'Breaking down food for energy',
                    'Cellular respiration',
                    'Nitrogen fixation'
                ],
                'correctAnswer': 'Converting light energy to chemical energy',
                'explanation': 'Photosynthesis is the process by which green plants and some other organisms use sunlight to synthesize foods with carbon dioxide and water, generating oxygen as a byproduct.'
            },
            {
                'question': 'Which organelle is the site of photosynthesis in plant cells?',
                'options': [
                    'Mitochondria',
                    'Chloroplast',
                    'Nucleus',
                    'Golgi apparatus'
                ],
                'correctAnswer': 'Chloroplast',
                'explanation': 'Chloroplasts contain chlorophyll, which captures light energy and is essential for photosynthesis.'
            },
            {
                'question': 'What are the two main stages of photosynthesis?',
                'options': [
                    'Glycolysis and Krebs cycle',
                    'Light-dependent reactions and Calvin cycle',
                    'Transcription and translation',
                    'Mitosis and meiosis'
                ],
                'correctAnswer': 'Light-dependent reactions and Calvin cycle',
                'explanation': 'The light-dependent reactions capture energy from sunlight, while the Calvin cycle uses that energy to produce glucose from carbon dioxide.'
            }
        ],
        'Cell Biology': [
            {
                'question': 'Which of the following is NOT a part of a plant cell?',
                'options': [
                    'Cell wall',
                    'Chloroplast',
                    'Flagellum',
                    'Vacuole'
                ],
                'correctAnswer': 'Flagellum',
                'explanation': 'Flagella are typically found in animal cells and some bacteria, not in plant cells.'
            },
            {
                'question': 'What is the function of the mitochondria?',
                'options': [
                    'Protein synthesis',
                    'Cellular respiration',
                    'Photosynthesis',
                    'Cell division'
                ],
                'correctAnswer': 'Cellular respiration',
                'explanation': 'Mitochondria are known as the powerhouse of the cell because they generate most of the cell\'s supply of ATP through cellular respiration.'
            }
        ],
        'Genetics': [
            {
                'question': 'What is the structure of DNA?',
                'options': [
                    'Single helix',
                    'Double helix',
                    'Triple helix',
                    'Quadruple helix'
                ],
                'correctAnswer': 'Double helix',
                'explanation': 'DNA has a double-helix structure, which was discovered by James Watson and Francis Crick in 1953.'
            },
            {
                'question': 'What is the process of making a protein from DNA called?',
                'options': [
                    'Replication',
                    'Transcription and translation',
                    'Mitosis',
                    'Meiosis'
                ],
                'correctAnswer': 'Transcription and translation',
                'explanation': 'Transcription is the process of making RNA from DNA, and translation is the process of making proteins from RNA.'
            }
        ],
        'Human Anatomy': [
            {
                'question': 'Which organ is responsible for filtering blood?',
                'options': [
                    'Liver',
                    'Kidney',
                    'Heart',
                    'Lung'
                ],
                'correctAnswer': 'Kidney',
                'explanation': 'The kidneys filter waste products from the blood and excrete them in urine.'
            }
        ],
        'Physics': [
            {
                'question': 'What is Newton\'s Second Law of Motion?',
                'options': [
                    'An object at rest stays at rest unless acted upon by a force',
                    'Force equals mass times acceleration',
                    'For every action, there is an equal and opposite reaction',
                    'Energy cannot be created or destroyed'
                ],
                'correctAnswer': 'Force equals mass times acceleration',
                'explanation': 'Newton\'s Second Law states that the acceleration of an object is directly proportional to the net force acting on it and inversely proportional to its mass.'
            }
        ],
        'Chemistry': [
            {
                'question': 'What is the pH of a neutral solution?',
                'options': [
                    '0',
                    '7',
                    '14',
                    '10'
                ],
                'correctAnswer': '7',
                'explanation': 'A pH of 7 is considered neutral, below 7 is acidic, and above 7 is basic or alkaline.'
            }
        ],
        'Mathematics': [
            {
                'question': 'What is the Pythagorean theorem?',
                'options': [
                    'a + b = c',
                    'a² + b² = c²',
                    'a³ + b³ = c³',
                    'a × b = c'
                ],
                'correctAnswer': 'a² + b² = c²',
                'explanation': 'The Pythagorean theorem states that in a right triangle, the square of the length of the hypotenuse equals the sum of the squares of the lengths of the other two sides.'
            }
        ],
        'History': [
            {
                'question': 'When did World War II end?',
                'options': [
                    '1939',
                    '1942',
                    '1945',
                    '1950'
                ],
                'correctAnswer': '1945',
                'explanation': 'World War II ended in 1945 with the surrender of Germany in May and Japan in September.'
            }
        ]
    }
    
    # Collect questions from detected topics
    all_questions = []
    for topic in topics:
        if topic in question_bank:
            all_questions.extend(question_bank[topic])
    
    # If we have more than 5 questions, randomly select 5
    if len(all_questions) > 5:
        all_questions = random.sample(all_questions, 5)
    
    return all_questions

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/generate-quiz', methods=['POST'])
def generate_quiz():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    
    file = request.files['file']
    
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    
    if file:
        # Save the uploaded file
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(file_path)
        
        try:
            # Load the model
            model = load_model()
            
            # Extract features
            features = extract_features(file_path, model)
            
            # Map features to topics
            topics = map_features_to_topics(features)
            
            # Generate questions
            questions = generate_questions(topics)
            
            return jsonify({
                'topics': topics,
                'questions': questions
            })
            
        except Exception as e:
            return jsonify({'error': str(e)}), 500
        
        finally:
            # Clean up - remove the uploaded file
            if os.path.exists(file_path):
                os.remove(file_path)
    
    return jsonify({'error': 'Unknown error'}), 500

if __name__ == '__main__':
    app.run(debug=True)

