"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Upload, Loader2 } from "lucide-react"
import Image from "next/image"
import { QuizDisplay } from "@/components/quiz-display"
import { generateQuizQuestions } from "@/lib/quiz-generator"

export default function GeneratePage() {
  const [file, setFile] = useState<File | null>(null)
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [quizQuestions, setQuizQuestions] = useState<any[]>([])
  const [activeTab, setActiveTab] = useState("upload")

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0]
    if (selectedFile) {
      setFile(selectedFile)

      // Create preview for images
      if (selectedFile.type.startsWith("image/")) {
        const reader = new FileReader()
        reader.onload = (e) => {
          setImagePreview(e.target?.result as string)
        }
        reader.readAsDataURL(selectedFile)
      } else {
        setImagePreview(null)
      }
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!file) return

    setIsLoading(true)
    try {
      // In a real application, you would upload the file to your backend
      // and process it with your CNN model

      // For demo purposes, we'll use a mock function to generate questions
      const questions = await generateQuizQuestions(file)
      setQuizQuestions(questions)
      setActiveTab("quiz")
    } catch (error) {
      console.error("Error generating quiz:", error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="container py-10">
      <h1 className="mb-6 text-3xl font-bold">Generate Educational Quiz</h1>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="upload">Upload Content</TabsTrigger>
          <TabsTrigger value="quiz" disabled={quizQuestions.length === 0}>
            Generated Quiz
          </TabsTrigger>
        </TabsList>

        <TabsContent value="upload">
          <Card>
            <CardHeader>
              <CardTitle>Upload Educational Content</CardTitle>
              <CardDescription>Upload an image of educational content to generate quiz questions.</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit}>
                <div className="grid w-full items-center gap-4">
                  <div className="flex flex-col space-y-1.5">
                    <Label htmlFor="content">Educational Content</Label>
                    <div className="flex items-center gap-2">
                      <Input
                        id="content"
                        type="file"
                        accept="image/*"
                        onChange={handleFileChange}
                        className="cursor-pointer"
                      />
                    </div>
                  </div>

                  {imagePreview && (
                    <div className="mt-4 rounded-lg border p-2">
                      <p className="mb-2 text-sm font-medium">Preview:</p>
                      <div className="relative h-64 w-full overflow-hidden rounded-lg">
                        <Image
                          src={imagePreview || "/placeholder.svg"}
                          alt="Content preview"
                          fill
                          className="object-contain"
                        />
                      </div>
                    </div>
                  )}

                  <Button type="submit" className="mt-4" disabled={!file || isLoading}>
                    {isLoading ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Processing...
                      </>
                    ) : (
                      <>
                        <Upload className="mr-2 h-4 w-4" />
                        Generate Quiz
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </CardContent>
            <CardFooter className="flex flex-col items-start">
              <p className="text-sm text-muted-foreground">Supported file types: JPG, PNG, GIF</p>
              <p className="text-sm text-muted-foreground">
                For best results, upload clear images of educational content.
              </p>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="quiz">
          <QuizDisplay questions={quizQuestions} />
        </TabsContent>
      </Tabs>
    </div>
  )
}

