import type { Metadata } from "next"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { BookOpen, Upload } from "lucide-react"

export const metadata: Metadata = {
  title: "Educational Quiz Generator",
  description: "Generate quiz questions from educational content using AI",
}

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center">
          <Link href="/" className="flex items-center gap-2 font-semibold">
            <BookOpen className="h-5 w-5" />
            <span>QuizGen AI</span>
          </Link>
          <nav className="flex flex-1 items-center justify-end space-x-2">
            <Button variant="default" asChild>
              <Link href="/generate">
                <Upload className="mr-2 h-4 w-4" />
                Generate Quiz
              </Link>
            </Button>
          </nav>
        </div>
      </header>
      <main className="flex-1">
        <section className="w-full py-12 md:py-24 lg:py-32">
          <div className="container px-4 md:px-6">
            <div className="flex flex-col items-center justify-center space-y-4 text-center">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl lg:text-6xl">
                  Automatic Educational Quiz Generator
                </h1>
                <p className="mx-auto max-w-[700px] text-gray-500 md:text-xl dark:text-gray-400">
                  Upload educational content and let our AI generate quiz questions automatically using CNN technology.
                </p>
              </div>
              <div className="space-x-4">
                <Button asChild size="lg">
                  <Link href="/generate">Get Started</Link>
                </Button>
              </div>
            </div>
          </div>
        </section>
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gray-100 dark:bg-gray-800">
          <div className="container px-4 md:px-6">
            <div className="grid gap-6 lg:grid-cols-3 lg:gap-12">
              <div className="space-y-4">
                <div className="inline-block rounded-lg bg-gray-100 p-3 dark:bg-gray-800">
                  <Upload className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-bold">Upload Content</h3>
                <p className="text-gray-500 dark:text-gray-400">
                  Upload images of textbooks, diagrams, or educational materials.
                </p>
              </div>
              <div className="space-y-4">
                <div className="inline-block rounded-lg bg-gray-100 p-3 dark:bg-gray-800">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="h-6 w-6"
                  >
                    <path d="M12 2v8"></path>
                    <path d="m4.93 10.93 1.41 1.41"></path>
                    <path d="M2 18h2"></path>
                    <path d="M20 18h2"></path>
                    <path d="m19.07 10.93-1.41 1.41"></path>
                    <path d="M22 22H2"></path>
                    <path d="m16 6-4 4-4-4"></path>
                    <path d="M16 18a4 4 0 0 0-8 0"></path>
                  </svg>
                </div>
                <h3 className="text-xl font-bold">AI Processing</h3>
                <p className="text-gray-500 dark:text-gray-400">
                  Our CNN model analyzes the content to identify key topics and concepts.
                </p>
              </div>
              <div className="space-y-4">
                <div className="inline-block rounded-lg bg-gray-100 p-3 dark:bg-gray-800">
                  <BookOpen className="h-6 w-6" />
                </div>
                <h3 className="text-xl font-bold">Generate Quiz</h3>
                <p className="text-gray-500 dark:text-gray-400">
                  Get automatically generated multiple-choice and short-answer questions.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>
      <footer className="border-t py-6 md:py-0">
        <div className="container flex flex-col items-center justify-between gap-4 md:h-24 md:flex-row">
          <p className="text-center text-sm leading-loose text-gray-500 md:text-left">
            © 2024 QuizGen AI. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  )
}

